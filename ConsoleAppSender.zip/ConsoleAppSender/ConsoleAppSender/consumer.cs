﻿namespace ConsoleAppSender
{
    internal class consumer
    {
        internal static System.Func<object, object, object> Received;
    }
}