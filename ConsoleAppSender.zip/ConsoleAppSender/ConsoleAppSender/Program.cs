﻿using RabbitMQ.Client;
using System;
using System.Text;

namespace ConsoleAppSender
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome");

            ConnectionFactory connectionFactory = new ConnectionFactory();
            connectionFactory.HostName = "localhost";
           
            using (var connection = connectionFactory.CreateConnection())
            using (var channel = connection.CreateModel())
                
            {
                channel.QueueDeclare(queue: "msgKey",
                                     durable: true,
                                     exclusive: false,
                                     autoDelete: false,
                                     arguments: null);

                Console.WriteLine("Enter your Name");
                string Name = Console.ReadLine();               
                var body = Encoding.UTF8.GetBytes(Name);
                channel.BasicPublish(exchange: "",
                                     routingKey: "msgKey",
                                     basicProperties: null,
                                     body: body);

              
                Console.WriteLine(" [x] Meaasge Sent {0}",Name);
            }

            
        }
    }
}
