﻿using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Text;

namespace ConsoleAppReceive
{
    class Receive
    {
        public static void Main()
        {
            var factory = new ConnectionFactory() { HostName = "localhost" };
            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {

                var consumer = new EventingBasicConsumer(channel);
                consumer.Received += (model, ea) =>
               {
                   var body = ea.Body;
                   var message = Encoding.UTF8.GetString(body);
                   Console.WriteLine("Hi  " + message + " I am your father");
                   string msg = Console.ReadLine();
               };

                channel.BasicConsume(queue: "msgKey",
                                    autoAck: true,
                                     consumer: consumer);



                channel.BasicConsume(queue: "msgKey1",
                                   autoAck: true,
                                    consumer: consumer);




                {
                    channel.QueueDeclare(queue: "msgKey",
                                         durable: true,
                                         exclusive: false,
                                         autoDelete: false,
                                         arguments: null);

                    Console.WriteLine("Type message and press enter to send ");
                    string msg = Console.ReadLine();

    
                        Console.WriteLine("Press Enter to exit");
                        string Name = Console.ReadLine();


                    }


                }
            }
        }
    }
